#include "missing_libc.h"

/// C-runtime patch
extern "C"
{
    // used deep inside FreeImage
    void* lfind( const void * key, const void * base, size_t num, size_t width, int (*fncomparison)(const void *, const void * ) )
    {
        char* Ptr = (char*)base;

        for ( size_t i = 0; i != num; i++, Ptr+=width )
        {
            if ( fncomparison( key, Ptr ) == 0 ) return Ptr;
        }

        return NULL;
    }

    // used in libcompress
    int fseeko64(FILE *stream, off64_t offset, int whence)
    {
        return fseek( stream, int( offset & 0xFFFFFFFF ), whence );
    }

    // used in libcompress
    off64_t ftello64(FILE *stream)
    {
        return ftell( stream );
    }


    void swab(const void *from, void *to, ssize_t n) {
    const int16_t *in = (int16_t*)from;
    int16_t *out = (int16_t*)to;
    int i;
    n /= 2;
    for (i = 0 ; i < n; i++) {
        out[i] = bswap_16(in[i]);
    }
    }
} // extern C
