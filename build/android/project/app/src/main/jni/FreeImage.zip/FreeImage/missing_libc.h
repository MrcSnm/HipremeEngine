#include <unistd.h>
#include <stdio.h>
#include <byteswap.h>

/// C-runtime patch
extern "C"
{
    // used deep inside FreeImage
    void* lfind( const void * key, const void * base, size_t num, size_t width, int (*fncomparison)(const void *, const void * ) );
    // used in libcompress
    int fseeko64(FILE *stream, off64_t offset, int whence);
    off64_t ftello64(FILE *stream);
    void swab(const void *from, void *to, ssize_t n);
} // extern C
